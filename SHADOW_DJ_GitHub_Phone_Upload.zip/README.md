# SHADOW DJ — Native Android 0.8

Native Android foundation for SHADOW DJ / MRDARKLORD.

Included:
- Two native ExoPlayer decks
- Local audio-file picker
- Independent deck play/pause and volume
- Crossfader and master volume
- MediaSessionService background-playback foundation
- Android media-session controls
- Cloud GitHub Actions workflow for building a debug APK

YouTube/Jango are not captured, copied, or bypassed. Any future provider integration must use supported playback methods.

This is the Android source project, not an APK. The included cloud workflow is designed for the user's current no-working-computer situation.
