# SHADOW DJ — Native Android Phase 7

This is the native Android project for SHADOW DJ.

Current foundation:
- Two local audio decks
- Audio file picker
- Play/pause
- Cue
- Crossfader
- Master volume
- Media3/ExoPlayer
- MediaSessionService background playback
- Android media notification foundation
- GitHub Actions workflow that can build a debug APK in the cloud

PHONE-ONLY ROUTE:
Because the owner currently has no working computer, this project includes a GitHub Actions workflow. Once the project is uploaded to a GitHub repository, the workflow can build the APK in the cloud and expose it as a downloadable artifact.

YouTube/Jango are not captured or bypassed. Any future integration must use the provider's supported playback/integration methods.
