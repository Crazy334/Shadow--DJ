package com.shadowdj.app

import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    inner class LocalBinder : Binder() {
        fun service(): PlaybackService = this@PlaybackService
    }

    private val localBinder = LocalBinder()
    lateinit var deckA: ExoPlayer
        private set
    lateinit var deckB: ExoPlayer
        private set

    private var mediaSession: MediaSession? = null
    private var crossfader = 0.5f
    private var master = 1.0f
    private var userVolumeA = 1.0f
    private var userVolumeB = 1.0f

    override fun onCreate() {
        super.onCreate()
        deckA = ExoPlayer.Builder(this).build()
        deckB = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, deckA).build()
        applyMixer()
    }

    override fun onBind(intent: Intent?): IBinder? =
        if (intent?.action == ACTION_BIND_DJ) localBinder else super.onBind(intent)

    fun loadA(uri: String) {
        deckA.setMediaItem(MediaItem.fromUri(uri))
        deckA.prepare()
    }

    fun loadB(uri: String) {
        deckB.setMediaItem(MediaItem.fromUri(uri))
        deckB.prepare()
    }

    fun setCrossfader(value: Float) {
        crossfader = value.coerceIn(0f, 1f)
        applyMixer()
    }

    fun setMaster(value: Float) {
        master = value.coerceIn(0f, 1f)
        applyMixer()
    }

    fun setDeckVolume(deck: String, value: Float) {
        if (deck == "A") userVolumeA = value.coerceIn(0f, 1f)
        else userVolumeB = value.coerceIn(0f, 1f)
        applyMixer()
    }

    private fun applyMixer() {
        deckA.volume = ((1f - crossfader) * userVolumeA * master).coerceIn(0f, 1f)
        deckB.volume = (crossfader * userVolumeB * master).coerceIn(0f, 1f)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.release()
        deckA.release()
        deckB.release()
        super.onDestroy()
    }

    companion object {
        const val ACTION_BIND_DJ = "com.shadowdj.app.BIND_DJ"
    }
}
